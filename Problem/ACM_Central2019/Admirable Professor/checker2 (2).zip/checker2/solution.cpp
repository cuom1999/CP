#include <bits/stdc++.h>
#define ll long long

using namespace std;

ll tribo[55];

int main() {
	ll n;
	tribo[0] = 0;
	tribo[1] = 0;
	tribo[2] = 1;
	for (int i = 3; i <= 50; i++) tribo[i] = tribo[i-1] + tribo[i-2] + tribo[i-3];
	while (cin >> n) {
		for (int i = 0; i <= 50; i++)
			if (tribo[i] >= n) {
				cout << tribo[i] << endl;
				break;
			}
	}
	return 0;
}
