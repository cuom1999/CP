// this judge is only used for C++
// please write yourself another judge for another language

#include <bits/stdc++.h>
using namespace std;

const string SOL = "solution";
const string CHECKER = "checker";

int numTest = 25;

int main()
{
    srand(time(NULL));
    // compile to get the exe file of human solution
    system(("g++ " + SOL + ".cpp -o " + SOL).c_str());
    // compile the checker
    system(("g++ " + CHECKER + ".cpp -o " + CHECKER).c_str());
    for (int testID = 0; testID < numTest; testID++) {

        // some statements to convert testID to string
        string testID_str;
        stringstream convert;
        convert << testID;
        testID_str = convert.str();

        // run solution with each testcase
        system((SOL + " < testcases/" + testID_str + ".in > team_outputs/sol" + testID_str + ".out").c_str());
        // check with each testcase
        if (system((CHECKER + " testcases/" + testID_str + ".in testcases/" + testID_str + ".ans feedback/ " + testID_str + " < team_outputs/sol" + testID_str + ".out" ).c_str()) == 43) {
            cout << "Test " << testID << ": Wrong Answer\n";
        }
        else {
            cout << "Test " << testID << ": Accepted\n";
        }
    }
    return 0;
}
